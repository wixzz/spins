var _0x3a51 = ["onColor", "defaults", "bootstrapSwitch", "fn", "success", "#aesInput", "width", "top", "offset", "href", "attr", "animate", "html, body", "click", "nav ul .normal-menu a, .scroll-link", "fadeToggle", ".normal-menu", ".mobile-menu", "E8VHK-FQA4J-2DH9D-FJHDX-XXXXX", "GDZ2T-TW8X2-4XS7V-DH9TC-XXXXX", "YCGJX-9MRCP-F4KR3-8P4VX-XXXXX", "FCB8J-J2W27-TTRF6-JGFTJ-XXXXX", "RKXTY-YCB6C-46HY4-CQKYM-XXXXX", "V8XDR-7MDDX-2QMD4-MWVFM-XXXXX", "WYYQB-Q2VDH-497F6-79VBQ-XXXXX", "VXD4M-3QCFR-YHB83-24MY6-XXXXX", 
"VF2P9-VTDJW-Y2CDK-TG6VH-XXXXX", "WV8GF-3MY8B-QXKHY-BDXTW-XXXXX", "QFQCW-C9TWH-MQQXQ-4BRJ8-XXXXX", "WKD4D-83VCT-8W7QP-TKXTG-XXXXX", "CFCCH-FMYJW-PM8P3-RY9XM-XXXXX", "TDMCB-PKCQJ-R9D32-QX3RD-XXXXX", "random", "length", "floor", "html", ".generated_code p", "NONE", "val", "#usernameInput", "", "#deviceInput", "text", "#m-accname", "#m-device", "#loading_modal", "inline", "progress_done", "log", "inactive", "removeClass", "#gen_section", "display", "block", "css", ".connected_msg", "disabled", "true", 
"#usernameInput, #deviceInput, #aesInput", "close", "magnificPopup", "Success", "Account ", " has been successfully connected.", "closed", "open", "Error", "Please select your server.", "error", "Please enter your username.", "You are already connected.", ".connect-button", "activated", "hasClass", ".", "OPTION_", "addClass", "slow", "#lives_select", "#coins_select", "#bars_select", "locker", "#gen_modal", "fadeIn", ".gen-console-area", "fadeOut", ".generator-section", "Please connect to your account.", 
".gen-button", ".connect_progressbar", "0%", "%", ".gen-dev-console", ".dev-console-text", "height", ".gen-loading-msg", '<li><i class="fa fa-angle-right"></i> ', "</li>", "appendTo", "hide", '<li class="console-green-text"><i class="fa fa-angle-right"></i> ', '<li class="console-red-text"><i class="fa fa-angle-right"></i> ', '<li class="console-yellow-text"><i class="fa fa-angle-right"></i> ', "Performing server authentication: connect_to_server(332FS2);", "Successully obtained server status verification", 
"Response: Successfully authenticated secure server connection.", "Importing files for encryption of user request", "Import: AES_256_Keys();", "Import: Open_SSL_Encryption();", "Import: Server_332FS2_Keychain();", "Importing of encryption files and methods completed", "Response: All files were imported successfully.", "Retrieving form input information: kernel.forms.obtain_user_information();", "User HTTP request information has been obtained", "Response: Obtained user form input information.", "USERNAME: ", 
"DEVICE: ", "COINS_AMOUNT: ", "POINTS_AMOUNT: ", "Injecting the information securely into encryption server: kernel.generator.start_process();", "User information is being encrypted", "Encrypting request: kernel.open_ssl_enc(", ");", "User information encryption completed", "Response: Successfully encrypted user request.", "Encrypted Information: 608c4a1b463ec35ad0354c1edd5ae961add292b6675cbca8ac41d70d37d4e2a7dba2b", "Retrieving current PRS server script: read_PRS_server_source();", "Obtaining methods to create a backdoor into PRS server", 
"Response: Successfully obtained current server script.", "MD5 hash: 2c58b6d627de1c58cc4fda16e1037a08", "Local IP address: 192.168.5.6", "Current version: 2.320.23.1", "Login server version: 1.32.4.5", "Number external methods: 43267", "Initialization method: kernel.cc_server.application.main.init();", "Injecting into main method: inject_ssl(kernel.cc_server.application.main.init);", "Processing orginal user request to confirm human source", "Response: Successfully injected into PRS servers.", "border-left", 
"1.1em solid #29be62", ".loading-spinner", "Items generation successful.", "Sending item to (", ") from our server.", "Initating redirect procedure.", "Redirecting to human verification screen", "You can post a message after using the generator tool.", ".comment_btn", "ready"];
$(document)[_0x3a51[148]](function() {
  /**
   * @return {undefined}
   */
  function shim() {
    $random_number = Math[_0x3a51[34]](Math[_0x3a51[32]]() * _0xd05bx2[_0x3a51[33]]);
    $(_0x3a51[36])[_0x3a51[35]](_0xd05bx2[$random_number]);
  }
  /**
   * @param {?} dataAndEvents
   * @param {number} skip
   * @return {?}
   */
  function clone(dataAndEvents, skip) {
    var r;
    /** @type {number} */
    i = 1;
    for (;i <= 5;i++) {
      if ($(_0x3a51[74] + skip + i)[_0x3a51[73]](_0x3a51[72])) {
        $(_0x3a51[74] + skip + i)[_0x3a51[50]](_0x3a51[72]);
      }
    }
    /** @type {number} */
    i = 1;
    for (;i <= 5;i++) {
      if (dataAndEvents[_0x3a51[73]](skip + i)) {
        r = _0x3a51[75] + i;
      }
    }
    dataAndEvents[_0x3a51[76]](_0x3a51[72]);
    return r;
  }
  /**
   * @param {Function} callback
   * @return {undefined}
   */
  function loaded(callback) {
    /** @type {number} */
    var y = 0;
    var ctx = $(_0x3a51[89]);
    ctx[_0x3a51[54]](_0x3a51[6], _0x3a51[90]);
    /** @type {number} */
    var poll = setInterval(function() {
      if (y == 0) {
        /** @type {number} */
        y = 20;
        ctx[_0x3a51[54]](_0x3a51[6], y + _0x3a51[91]);
      } else {
        if (y == 20) {
          /** @type {number} */
          y = 35;
          ctx[_0x3a51[54]](_0x3a51[6], y + _0x3a51[91]);
        } else {
          if (y == 35) {
            /** @type {number} */
            y = 65;
            ctx[_0x3a51[54]](_0x3a51[6], y + _0x3a51[91]);
          } else {
            if (y == 65) {
              /** @type {number} */
              y = 75;
              ctx[_0x3a51[54]](_0x3a51[6], y + _0x3a51[91]);
            } else {
              if (y == 75) {
                /** @type {number} */
                y = 85;
                ctx[_0x3a51[54]](_0x3a51[6], y + _0x3a51[91]);
              } else {
                if (y == 85) {
                  /** @type {number} */
                  y = 89;
                  ctx[_0x3a51[54]](_0x3a51[6], y + _0x3a51[91]);
                } else {
                  if (y == 89) {
                    /** @type {number} */
                    y = 100;
                    ctx[_0x3a51[54]](_0x3a51[6], y + _0x3a51[91]);
                  } else {
                    if (y == 100) {
                      callback();
                      clearInterval(poll);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }, Math[_0x3a51[34]](Math[_0x3a51[32]]() * 1200 + 600));
  }
  /**
   * @param {?} resp
   * @param {number} opt_attributes
   * @return {undefined}
   */
  function poll(resp, opt_attributes) {
    setTimeout(function() {
      var collection = $(_0x3a51[95]);
      collection[_0x3a51[35]](resp);
    }, opt_attributes);
  }
  /**
   * @param {?} event
   * @param {number} opt_attributes
   * @return {undefined}
   */
  function onComplete(event, opt_attributes) {
    setTimeout(function() {
      var $spy = $(_0x3a51[96] + event + _0x3a51[97]);
      $spy[_0x3a51[99]]()[_0x3a51[98]](relatedTarget)[_0x3a51[83]]();
      emptyJ[_0x3a51[11]]({
        scrollTop : top
      }, 500);
      top += emptyJ[_0x3a51[94]]();
    }, opt_attributes);
  }
  /**
   * @param {?} res
   * @param {number} opt_attributes
   * @return {undefined}
   */
  function onSuccess(res, opt_attributes) {
    setTimeout(function() {
      var $spy = $(_0x3a51[100] + res + _0x3a51[97]);
      $spy[_0x3a51[99]]()[_0x3a51[98]](relatedTarget)[_0x3a51[83]]();
      emptyJ[_0x3a51[11]]({
        scrollTop : top
      }, 500);
      top += emptyJ[_0x3a51[94]]();
    }, opt_attributes);
  }
  /**
   * @param {?} n
   * @param {?} t
   * @return {undefined}
   */
  function f(n, t) {
    setTimeout(function() {
      var $spy = $(_0x3a51[101] + n + _0x3a51[97]);
      $spy[_0x3a51[99]]()[_0x3a51[98]](relatedTarget)[_0x3a51[83]]();
      emptyJ[_0x3a51[11]]({
        scrollTop : top
      }, 500);
      top += emptyJ[_0x3a51[94]]();
    }, t);
  }
  /**
   * @param {?} textStatus
   * @param {number} opt_attributes
   * @return {undefined}
   */
  function error(textStatus, opt_attributes) {
    setTimeout(function() {
      var $spy = $(_0x3a51[102] + textStatus + _0x3a51[97]);
      $spy[_0x3a51[99]]()[_0x3a51[98]](relatedTarget)[_0x3a51[83]]();
      emptyJ[_0x3a51[11]]({
        scrollTop : top
      }, 500);
      top += emptyJ[_0x3a51[94]]();
    }, opt_attributes);
  }
  /**
   * @param {?} e
   * @param {?} file
   * @param {?} ctx
   * @param {?} data
   * @param {?} event
   * @param {Function} func
   * @return {undefined}
   */
  function onload(e, file, ctx, data, event, func) {
    onComplete(_0x3a51[103], 0);
    poll(_0x3a51[104], 300);
    onSuccess(_0x3a51[105], 750);
    poll(_0x3a51[106], 1200);
    onComplete(_0x3a51[107], 1400);
    onComplete(_0x3a51[108], 1600);
    onComplete(_0x3a51[109], 1880);
    poll(_0x3a51[110], 2E3);
    onSuccess(_0x3a51[111], 2400);
    onComplete(_0x3a51[112], 2670);
    poll(_0x3a51[113], 2900);
    onSuccess(_0x3a51[114], 3100);
    error(_0x3a51[115] + e, 3400);
    error(_0x3a51[116] + file, 3500);
    error(_0x3a51[117] + ctx, 3500);
    error(_0x3a51[118] + data, 3500);
    onComplete(_0x3a51[119], 4200);
    poll(_0x3a51[120], 4400);
    onComplete(_0x3a51[121] + e + _0x3a51[122], 4700);
    poll(_0x3a51[123], 5E3);
    onSuccess(_0x3a51[124], 5300);
    onSuccess(_0x3a51[125], 5600);
    onComplete(_0x3a51[126], 6E3);
    poll(_0x3a51[127], 6100);
    onSuccess(_0x3a51[128], 6400);
    error(_0x3a51[129], 6900);
    error(_0x3a51[130], 7100);
    error(_0x3a51[131], 7200);
    error(_0x3a51[132], 7300);
    error(_0x3a51[133], 7400);
    error(_0x3a51[134], 7600);
    onComplete(_0x3a51[135], 8E3);
    poll(_0x3a51[136], 8250);
    onSuccess(_0x3a51[137], 8430);
    setTimeout(function() {
      $(_0x3a51[140])[_0x3a51[54]](_0x3a51[138], _0x3a51[139]);
    }, 8900);
    onSuccess(_0x3a51[141], 8900);
    onSuccess(_0x3a51[142] + e + _0x3a51[143], 8900);
    onSuccess(_0x3a51[144], 8900);
    poll(_0x3a51[145], 9400);
    setTimeout(function() {
      func();
    }, 12500);
  }
  $[_0x3a51[3]][_0x3a51[2]][_0x3a51[1]][_0x3a51[0]] = _0x3a51[4];
  $(_0x3a51[5])[_0x3a51[2]]();
  var _0xd05bx1 = $(window)[_0x3a51[6]]();
  $(_0x3a51[14])[_0x3a51[13]](function() {
    $(_0x3a51[12])[_0x3a51[11]]({
      scrollTop : $($[_0x3a51[10]](this, _0x3a51[9]))[_0x3a51[8]]()[_0x3a51[7]] - 30
    }, 500);
    return false;
  });
  $(_0x3a51[17])[_0x3a51[13]](function() {
    $(_0x3a51[16])[_0x3a51[15]]();
  });
  /** @type {Array} */
  var _0xd05bx2 = [_0x3a51[18], _0x3a51[19], _0x3a51[20], _0x3a51[21], _0x3a51[22], _0x3a51[23], _0x3a51[24], _0x3a51[25], _0x3a51[26], _0x3a51[27], _0x3a51[28], _0x3a51[29], _0x3a51[30], _0x3a51[31]];
  shim();
  /** @type {boolean} */
  var _0xd05bx4 = false;
  var _0xd05bx5 = _0x3a51[37];
  var _0xd05bx6 = _0x3a51[37];
  $(_0x3a51[71])[_0x3a51[13]](function(dataAndEvents) {
    if (_0xd05bx4 == false) {
      if ($(_0x3a51[39])[_0x3a51[38]]() != _0x3a51[40]) {
        if ($(_0x3a51[41])[_0x3a51[38]]() != _0x3a51[40]) {
          $(_0x3a51[43])[_0x3a51[42]]($(_0x3a51[39])[_0x3a51[38]]());
          $(_0x3a51[44])[_0x3a51[42]]($(_0x3a51[41])[_0x3a51[38]]());
          $[_0x3a51[60]][_0x3a51[65]]({
            items : {
              src : _0x3a51[45]
            },
            type : _0x3a51[46],
            preloader : false,
            modal : true,
            callbacks : {
              /**
               * @return {undefined}
               */
              open : function() {
                loaded(function() {
                  console[_0x3a51[48]](_0x3a51[47]);
                  /** @type {boolean} */
                  _0xd05bx4 = true;
                  $(_0x3a51[51])[_0x3a51[50]](_0x3a51[49]);
                  $(_0x3a51[55])[_0x3a51[54]](_0x3a51[52], _0x3a51[53]);
                  $(_0x3a51[58])[_0x3a51[10]](_0x3a51[56], _0x3a51[57]);
                  $[_0x3a51[60]][_0x3a51[59]]();
                  sweetAlert(_0x3a51[61], _0x3a51[62] + $(_0x3a51[39])[_0x3a51[38]]() + _0x3a51[63], _0x3a51[4]);
                });
              },
              /**
               * @return {undefined}
               */
              close : function() {
                console[_0x3a51[48]](_0x3a51[64]);
              }
            }
          });
        } else {
          sweetAlert(_0x3a51[66], _0x3a51[67], _0x3a51[68]);
        }
      } else {
        sweetAlert(_0x3a51[66], _0x3a51[69], _0x3a51[68]);
      }
    } else {
      sweetAlert(_0x3a51[66], _0x3a51[70], _0x3a51[68]);
    }
  });
  $(_0x3a51[88])[_0x3a51[13]](function() {
    if (_0xd05bx4 == true) {
      $(_0x3a51[86])[_0x3a51[85]](_0x3a51[77], function() {
        $(_0x3a51[84])[_0x3a51[83]](_0x3a51[77], function() {
          onload($(_0x3a51[39])[_0x3a51[38]](), $(_0x3a51[41])[_0x3a51[38]](), $(_0x3a51[78])[_0x3a51[38]](), $(_0x3a51[79])[_0x3a51[38]](), $(_0x3a51[80])[_0x3a51[38]](), function() {
            console[_0x3a51[48]](_0x3a51[81]);
            $[_0x3a51[60]][_0x3a51[65]]({
              items : {
                src : _0x3a51[82]
              },
              type : _0x3a51[46],
              preloader : false,
              modal : true,
              callbacks : {
                /**
                 * @return {undefined}
                 */
                open : function() {
                }
              }
            });
          });
          $(_0x3a51[12])[_0x3a51[11]]({
            scrollTop : $(_0x3a51[51])[_0x3a51[8]]()[_0x3a51[7]] - 30
          }, 100);
        });
      });
    } else {
      sweetAlert(_0x3a51[66], _0x3a51[87], _0x3a51[68]);
    }
  });
  var emptyJ = $(_0x3a51[92]);
  var relatedTarget = $(_0x3a51[93]);
  var top = emptyJ[_0x3a51[94]]();
  $(_0x3a51[147])[_0x3a51[13]](function() {
    sweetAlert(_0x3a51[66], _0x3a51[146], _0x3a51[68]);
  });
});